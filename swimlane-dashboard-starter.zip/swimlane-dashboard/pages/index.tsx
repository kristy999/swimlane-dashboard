import { useEffect, useState } from "react";
import { useTaskStore } from "@/store/useTaskStore";
import Swimlane from "@/components/Swimlane";
import SearchBar from "@/components/SearchBar";

export default function Home() {
  const { tasks, setTasks } = useTaskStore();
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const localData = localStorage.getItem("tasks");
    if (localData) {
      setTasks(JSON.parse(localData));
    } else {
      fetch("/tasks.json")
        .then((res) => res.json())
        .then((data) => setTasks(data));
    }
  }, [setTasks]);

  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  return (
    <main className="p-4">
      <SearchBar query={searchQuery} setQuery={setSearchQuery} />
      <div className="flex gap-4 mt-4 overflow-x-auto">
        {["To Do", "In Progress", "Done"].map((status) => (
          <Swimlane key={status} status={status} searchQuery={searchQuery} />
        ))}
      </div>
    </main>
  );
}
