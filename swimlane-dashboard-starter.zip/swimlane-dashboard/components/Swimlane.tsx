import { useTaskStore } from "@/store/useTaskStore";
import TaskCard from "./TaskCard";

interface Props {
  status: string;
  searchQuery: string;
}

export default function Swimlane({ status, searchQuery }: Props) {
  const { tasks } = useTaskStore();
  const filtered = tasks.filter((t) =>
    t.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
    t.status === status
  );

  return (
    <div className="w-80 bg-gray-100 p-3 rounded-md shadow-md flex-shrink-0">
      <h2 className="text-xl font-semibold mb-2">{status}</h2>
      {filtered.map((task) => (
        <TaskCard key={task.id} task={task} />
      ))}
    </div>
  );
}
