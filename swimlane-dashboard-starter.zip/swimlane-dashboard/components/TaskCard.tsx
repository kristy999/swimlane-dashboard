interface Props {
  task: { id: string; title: string; description: string };
}

export default function TaskCard({ task }: Props) {
  return (
    <div className="bg-white p-3 rounded shadow mb-2">
      <h3 className="font-bold">{task.title}</h3>
      <p className="text-sm text-gray-600">{task.description}</p>
    </div>
  );
}
