interface Props {
  query: string;
  setQuery: (query: string) => void;
}

export default function SearchBar({ query, setQuery }: Props) {
  return (
    <input
      className="w-full p-2 border rounded-md"
      placeholder="Search tasks..."
      value={query}
      onChange={(e) => setQuery(e.target.value)}
    />
  );
}
